package Exception;

/**
 *
 * @author Nguyen Van Viet
 */
public class NullValueException extends Exception {
    public NullValueException(){}
    public NullValueException(String mess){
        super(mess);
    }

}